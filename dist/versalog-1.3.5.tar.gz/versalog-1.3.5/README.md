## What is VersaLog.py?

VersaLog is a library that enables highly functional and flexible logging.

## Installation

```
pip install VersaLog
```

## Sample

**Simple** : [Tap](https://github.com/kayu0514/VersaLog.py/blob/main/tests/simple_test.py)  
**Detailed** : [Tap](https://github.com/kayu0514/VersaLog.py/blob/main/tests/detailed_test.py)
**File** : [Tap](https://github.com/kayu0514/VersaLog.py/blob/main/tests/file_test.py)
